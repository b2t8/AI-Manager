import { Router, type IRouter } from "express";
import healthRouter from "./health";
import executiveRouter from "./executive";

const router: IRouter = Router();

router.use(healthRouter);
router.use(executiveRouter);

export default router;
