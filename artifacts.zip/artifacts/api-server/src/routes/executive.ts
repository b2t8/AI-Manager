import { Router, type IRouter, type Request, type Response } from "express";
import {
  CreateTaskBody,
  DeleteTaskParams,
  RunAgentBody,
  UpdateMemorySettingsBody,
  UpdateTaskBody,
  UpdateTaskParams,
} from "@workspace/api-zod";

type Task = {
  id: string;
  title: string;
  due: string;
  priority: "high" | "medium" | "low";
  status: "todo" | "in_progress" | "done";
  category: string;
};

const tasks: Task[] = [
  {
    id: "brief-1",
    title: "مراجعة موجز الاستثمار للربع القادم",
    due: "اليوم، ١١:٣٠",
    priority: "high",
    status: "in_progress",
    category: "استراتيجية",
  },
  {
    id: "brief-2",
    title: "إرسال ملاحظات اجتماع مجلس الإدارة",
    due: "اليوم، ١٤:٠٠",
    priority: "medium",
    status: "todo",
    category: "إدارة",
  },
  {
    id: "brief-3",
    title: "تأكيد حجز الفندق في لندن",
    due: "غداً، ٠٩:٠٠",
    priority: "low",
    status: "todo",
    category: "سفر",
  },
  {
    id: "brief-4",
    title: "مكالمة متابعة مع فريق المنتج",
    due: "الأحد، ١٠:٠٠",
    priority: "medium",
    status: "done",
    category: "فريق",
  },
];

const activity = [
  {
    id: "activity-1",
    title: "أعد ملخص اجتماع القيادة",
    detail: "استخرج ٦ قرارات ووزّع ٤ مهام",
    time: "منذ ٨ دقائق",
    status: "completed" as const,
  },
  {
    id: "activity-2",
    title: "يراقب صندوق الوارد",
    detail: "وجد ٣ رسائل تحتاج إلى قرارك",
    time: "الآن",
    status: "active" as const,
  },
  {
    id: "activity-3",
    title: "تذكير: مراجعة ميزانية السفر",
    detail: "الموعد بعد ٣ ساعات",
    time: "مجدول",
    status: "pending" as const,
  },
];

const memories = [
  {
    id: "memory-1",
    label: "أسلوب التواصل",
    value: "أفضل ملخصات قصيرة مع النقاط الحاسمة أولاً",
    category: "تفضيلات",
  },
  {
    id: "memory-2",
    label: "المنطقة الزمنية",
    value: "الرياض (UTC+3)",
    category: "سياق",
  },
  {
    id: "memory-3",
    label: "نافذة التركيز",
    value: "من ٩:٠٠ إلى ١١:٣٠ صباحاً",
    category: "روتين",
  },
];

let memoryEnabled = true;

const dashboard = {
  greeting: "مساء الخير، محمد",
  dateLabel: "الخميس، ١٩ سبتمبر ٢٠٢٤",
  taskCount: 8,
  completedCount: 3,
  focusMinutes: 147,
  budgetUsed: 6840,
  budgetLimit: 12000,
  nextAppointment: "مراجعة مجلس الإدارة · ١٣:٣٠",
  suggestion: "لديك نافذة تركيز هادئة لمدة ٤٥ دقيقة قبل اجتماعك القادم.",
};

function sendValidationError(res: Response, error: unknown) {
  const message = error instanceof Error ? error.message : "بيانات غير صحيحة";
  res.status(400).json({ error: message });
}

function fallbackAgent(prompt: string) {
  const lowerPrompt = prompt.toLowerCase();
  const travel = lowerPrompt.includes("سفر") || lowerPrompt.includes("رحل");
  const expense = lowerPrompt.includes("مصروف") || lowerPrompt.includes("ميزاني");
  const meeting = lowerPrompt.includes("اجتماع");
  const intent = travel
    ? "travel_planning"
    : expense
      ? "expense_review"
      : meeting
        ? "meeting_brief"
        : "executive_planning";
  const steps = travel
    ? ["فهم الوجهة والقيود", "مقارنة الخيارات المتاحة", "ترتيب خط الرحلة", "التحقق من الحجوزات", "إرسال ملخص قابل للتنفيذ"]
    : expense
      ? ["تجميع المصروفات", "تصنيف البنود", "رصد الأنماط", "تحديد فرص التوفير", "إرسال توصية مختصرة"]
      : meeting
        ? ["قراءة سياق الاجتماع", "جمع القرارات السابقة", "تحضير نقاط النقاش", "صياغة الأسئلة المهمة", "إرسال موجز الاجتماع"]
        : ["فهم الطلب والسياق", "بناء خطة تنفيذ مختصرة", "تنفيذ ما يلزم بأمان", "التحقق من النتيجة", "إرسال تقرير واضح"];
  return {
    message: `فهمت طلبك: «${prompt}». جهزت مسارًا تنفيذيًا من ${steps.length} خطوات، وسأطلب تأكيدك قبل أي إجراء حساس.`,
    intent,
    steps,
    suggestedAction: travel
      ? "أرسل الوجهة والتواريخ وسأحوّلها إلى خطة سفر قابلة للمراجعة."
      : expense
        ? "افتح مساحة المصروفات لمراجعة الإشارة المالية بالتفصيل."
        : meeting
          ? "سأبدأ بموجز الاجتماع ثم أضع الأسئلة والقرارات المطلوبة أمامك."
          : "ابدأ بالخطوة الأولى أو أضف تفاصيل أكثر لأضبط الخطة.",
  };
}

async function runGemini(
  prompt: string,
  log?: { warn: (object: unknown, message?: string) => void },
) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${encodeURIComponent(key)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              {
                text: "أنت رصد، وكيل تنفيذي عربي. أجب بالعربية وباختصار. افهم الطلب ثم اقترح خطة من 3 إلى 5 خطوات، ولا تدّع تنفيذ إجراءات على الجهاز أو خدمات خارجية دون صلاحية مؤكدة. أعد JSON صالحًا بهذه المفاتيح: message, intent, steps (array), suggestedAction.",
              },
            ],
          },
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: "application/json" },
        }),
      },
    );
    if (!response.ok) {
      const providerError = await response.text();
      log?.warn(
        { status: response.status, providerError: providerError.slice(0, 500) },
        "Gemini request was rejected",
      );
      return null;
    }
    const payload = (await response.json()) as {
      candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    };
    const text = payload.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) return null;
    const parsed = JSON.parse(text.replace(/^```json\s*|\s*```$/g, "")) as {
      message: string;
      intent: string;
      steps: string[];
      suggestedAction: string;
    };
    if (!parsed.message || !Array.isArray(parsed.steps)) return null;
    return parsed;
  } catch (error) {
    log?.warn(
      { err: error instanceof Error ? error.message : "unknown error" },
      "Gemini request failed",
    );
    return null;
  }
}

const router: IRouter = Router();

router.get("/dashboard", (_req, res) => res.json(dashboard));
router.get("/tasks", (_req, res) => res.json(tasks));

router.post("/tasks", (req, res) => {
  try {
    const input = CreateTaskBody.parse(req.body);
    const task: Task = {
      id: `task-${Date.now()}`,
      title: input.title,
      due: input.due ?? "بدون موعد",
      priority: input.priority ?? "medium",
      status: "todo",
      category: input.category ?? "عام",
    };
    tasks.unshift(task);
    res.status(201).json(task);
  } catch (error) {
    sendValidationError(res, error);
  }
});

router.patch("/tasks/:id", (req, res) => {
  try {
    const { id } = UpdateTaskParams.parse(req.params);
    const updates = UpdateTaskBody.parse(req.body);
    const task = tasks.find((item) => item.id === id);
    if (!task) {
      res.status(404).json({ error: "المهمة غير موجودة" });
      return;
    }
    Object.assign(task, updates);
    res.json(task);
  } catch (error) {
    sendValidationError(res, error);
  }
});

router.delete("/tasks/:id", (req, res) => {
  try {
    const { id } = DeleteTaskParams.parse(req.params);
    const index = tasks.findIndex((item) => item.id === id);
    if (index === -1) {
      res.status(404).json({ error: "المهمة غير موجودة" });
      return;
    }
    tasks.splice(index, 1);
    res.status(204).send();
  } catch (error) {
    sendValidationError(res, error);
  }
});

router.get("/activity", (_req, res) => res.json(activity));
router.get("/memories", (_req, res) => res.json(memoryEnabled ? memories : []));

router.patch("/memories", (req, res) => {
  try {
    const input = UpdateMemorySettingsBody.parse(req.body);
    memoryEnabled = input.enabled;
    res.json({ enabled: memoryEnabled });
  } catch (error) {
    sendValidationError(res, error);
  }
});

router.post("/agent/run", async (req: Request, res: Response) => {
  try {
    const input = RunAgentBody.parse(req.body);
    const result =
      (await runGemini(input.prompt, req.log)) ?? fallbackAgent(input.prompt);
    req.log.info({ intent: result.intent }, "Executive agent request completed");
    res.json(result);
  } catch (error) {
    sendValidationError(res, error);
  }
});

export default router;