import { type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { Activity, BrainCircuit, CalendarDays, ChevronLeft, Command, CreditCard, LayoutDashboard, Menu, Plane, Settings, Sparkles, X } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { href: '/', label: 'نظرة تنفيذية', icon: LayoutDashboard },
  { href: '/assistant', label: 'مساحة الوكيل', icon: Sparkles },
  { href: '/tasks', label: 'المهام', icon: Command },
  { href: '/calendar', label: 'المواعيد', icon: CalendarDays },
  { href: '/trips', label: 'الرحلات', icon: Plane },
  { href: '/expenses', label: 'المصروفات', icon: CreditCard },
];
const controlItems = [
  { href: '/memory', label: 'ذاكرة الوكيل', icon: BrainCircuit },
  { href: '/settings', label: 'الإعدادات', icon: Settings },
];

export function AgentShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const pageLabel = [...navItems, ...controlItems].find((item) => item.href === location)?.label ?? 'نظرة تنفيذية';
  return (
    <div dir="rtl" className="executive-shell grain text-foreground">
      <button data-testid="button-mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} className="fixed right-4 top-4 z-50 flex h-11 w-11 items-center justify-center rounded-xl border border-border bg-card text-muted-foreground shadow-lg md:hidden">
        {mobileOpen ? <X size={19} /> : <Menu size={19} />}
      </button>
      {mobileOpen && <button aria-label="إغلاق القائمة" data-testid="button-close-mobile-menu" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-30 bg-black/45 md:hidden" />}
      <aside className={`sidebar-glass fixed inset-y-0 right-0 z-40 flex w-[268px] flex-col border-l border-sidebar-border px-4 py-5 transition-transform duration-300 md:translate-x-0 ${mobileOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="mb-9 flex items-center gap-3 px-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-primary/40 bg-primary/10 text-primary">
            <Sparkles size={20} strokeWidth={1.8} />
            <span className="absolute -left-1 -top-1 h-2 w-2 rounded-full bg-accent" />
          </div>
          <div>
            <div className="font-bold tracking-tight text-slate-100">رَصْد</div>
            <div className="text-[10px] tracking-[.14em] text-primary/70">EXECUTIVE AGENT</div>
          </div>
        </div>
        <div className="mb-3 px-3 text-[10px] font-semibold tracking-[.16em] text-muted-foreground">مساحة العمل</div>
        <nav className="space-y-1">
          {navItems.map((item) => <NavItem key={item.href} item={item} active={location === item.href} onNavigate={() => setMobileOpen(false)} />)}
        </nav>
        <div className="mb-3 mt-8 px-3 text-[10px] font-semibold tracking-[.16em] text-muted-foreground">التحكم والخصوصية</div>
        <nav className="space-y-1">
          {controlItems.map((item) => <NavItem key={item.href} item={item} active={location === item.href} onNavigate={() => setMobileOpen(false)} />)}
        </nav>
        <div className="mt-auto rounded-2xl border border-primary/15 bg-primary/[.045] p-4">
          <div className="mb-3 flex items-center gap-2 text-xs font-semibold text-slate-200"><span className="status-dot h-2 w-2 rounded-full bg-emerald-400" /> الوكيل متصل</div>
          <p className="text-[11px] leading-5 text-muted-foreground">آخر مزامنة منذ ٢ دقيقة. كل أنظمتك تحت المراقبة.</p>
          <Link href="/settings" data-testid="link-sidebar-settings" className="mt-3 flex items-center justify-between text-xs font-semibold text-primary hover:text-primary/80">إدارة الاتصال <ChevronLeft size={14} /></Link>
        </div>
      </aside>
      <main className="min-h-[100dvh] md:pr-[268px]">
        <header className="flex h-[78px] items-center justify-between border-b border-border/60 px-5 pt-1 md:px-10">
          <div>
            <div className="mb-1 text-[11px] font-semibold tracking-[.18em] text-primary/70">مركز القيادة / {pageLabel}</div>
            <div className="text-sm text-muted-foreground">الخميس، ١٩ سبتمبر ٢٠٢٤</div>
          </div>
          <div className="hidden items-center gap-3 sm:flex">
            <Link href="/assistant" data-testid="link-header-command" className="flex items-center gap-2 rounded-xl border border-primary/20 bg-primary/5 px-3 py-2 text-xs font-semibold text-primary transition hover:bg-primary/10"><Activity size={14} /> اطلب من الوكيل</Link>
            <div className="flex h-9 w-9 items-center justify-center rounded-full border border-accent/30 bg-accent/10 text-xs font-bold text-accent">م</div>
          </div>
        </header>
        <div className="mx-auto max-w-[1480px] px-5 py-7 md:px-10 md:py-9">{children}</div>
      </main>
    </div>
  );
}

function NavItem({ item, active, onNavigate }: { item: typeof navItems[number]; active: boolean; onNavigate: () => void }) {
  const Icon = item.icon;
  return <Link href={item.href} onClick={onNavigate} data-testid={`link-nav-${item.href === '/' ? 'overview' : item.href.slice(1)}`} className={`group flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition ${active ? 'bg-primary/10 font-semibold text-primary' : 'text-muted-foreground hover:bg-sidebar-accent hover:text-slate-100'}`}>
    <Icon size={17} strokeWidth={active ? 2.2 : 1.8} />
    <span>{item.label}</span>
    {active && <span className="mr-auto h-1.5 w-1.5 rounded-full bg-primary" />}
  </Link>;
}

export function PageTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
    <div className="reveal">
      <div className="mb-2 text-[11px] font-bold tracking-[.2em] text-primary">{eyebrow}</div>
      <h1 className="text-balance text-3xl font-bold tracking-tight text-slate-100 md:text-4xl">{title}</h1>
      {description && <p className="mt-2 max-w-2xl text-sm leading-7 text-muted-foreground">{description}</p>}
    </div>
    {action && <div className="reveal reveal-delay-1 shrink-0">{action}</div>}
  </div>;
}

export function LoadingPanel({ label = 'جارٍ تجهيز البيانات' }: { label?: string }) {
  return <div className="panel flex min-h-36 items-center justify-center rounded-2xl" data-testid="status-loading"><div className="flex items-center gap-3 text-sm text-muted-foreground"><span className="pulse-soft h-2 w-2 rounded-full bg-primary" />{label}</div></div>;
}
export function ErrorPanel({ retry }: { retry?: () => void }) {
  return <div className="panel flex min-h-36 flex-col items-center justify-center rounded-2xl text-center" data-testid="status-error"><div className="mb-2 text-sm font-semibold text-red-300">تعذر الوصول إلى بيانات الوكيل</div><p className="mb-4 text-xs text-muted-foreground">تحقق من الاتصال ثم أعد المحاولة.</p>{retry && <button data-testid="button-retry" onClick={retry} className="rounded-lg border border-border px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-muted">إعادة المحاولة</button>}</div>;
}
export function EmptyPanel({ title, detail }: { title: string; detail: string }) {
  return <div className="panel flex min-h-36 flex-col items-center justify-center rounded-2xl text-center" data-testid="status-empty"><div className="mb-2 text-sm font-semibold text-slate-200">{title}</div><p className="text-xs text-muted-foreground">{detail}</p></div>;
}